package monitoredebv;

import java.sql.Connection;
import java.sql.*;

public class OracleCon {
	
	//Class.forName("oracle.jdbc.driver.OracleDriver");
	//Connection con = DriverManager.getConnection("jdbc:oracle:thin:@odbpsebvl.eb.lan.at:1521:ebvdbt.ebvldb", "ITMONITOR", "B73jGhe$wutj1mfi");

	public static void main(String[]args) throws Exception {
		createTable();
	}
	
	/*public static void post() throws Exception{
		
		try {
			Connection dbcon = getConnection();
			PreparedStatement posted = dbcon.prepareStatement("INSERT INTO schnittstellen () VALUES()");
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
	*/
	
	public static void createTable() throws Exception{
		
		try {
			Connection dbcon = getConnection();
			//PreparedStatement createmail = dbcon.prepareStatement("CREATE TABLE IF NOT EXISTS alertemail(id int NOT NULL AUTO_INCREMENT,vorname varchar(255), nachname varchar(255), email varchar(255), PRIMARY KEY(id))");
			PreparedStatement create = dbcon.prepareStatement("CREATE TABLE IF NOT EXISTS schnittstelle(id int NOT NULL AUTO_INCREMENT,url varchar(255), status int,antwortzeit int");
			create.executeUpdate();
			//createmail.executeUpdate();
			
		}catch(Exception e) {
			System.out.println(e);
		}
		finally {System.out.println("Function completed.");}
		
	}

	public static Connection getConnection() throws Exception {
		try {
			
			String driver ="oracle.jdbc.driver.OracleDriver";
			String url = "jdbc:oracle:thin:@odbpsebvl.eb.lan.at:1521:ebvdbt.ebvldb";
			String username ="ITMONITOR";
			String password ="B73jGhe$wutj1mfi";
			
			Class.forName(driver);
			Connection dbcon = DriverManager.getConnection(url,username,password);
			System.out.println("Connected");
			return dbcon;
		}catch(Exception e) {
			System.out.println(e);
		}	
		return null;
	}
	
	
}
