package monitoredebv;

import java.sql.Connection;
import java.sql.*;

public class OracleCon {
	

	public static void main(String[]args) throws Exception {
		getConnection();
				
	}//main
	
	 public static Connection getConnection() throws Exception {
			try {
							
				String driver ="oracle.jdbc.driver.OracleDriver";
				String url = "jdbc:oracle:thin:@odbpsebvl.eb.lan.at:1521:ebvdbt.ebvldb";
				String username ="ITMONITOR";
				String password ="B73jGhe$wutj1mfi";
														
				
				Class.forName(driver);
				Connection dbcon = DriverManager.getConnection(url,username,password);
				System.out.println("Connected.");

				
				PreparedStatement createdb=dbcon.prepareStatement("CREATE DATABASE IF NOT EXISTS ebvdbt.ebvldb");
				PreparedStatement usedb=dbcon.prepareStatement("USE ebvdbt.ebvldb");
				PreparedStatement create = dbcon.prepareStatement("CREATE TABLE IF NOT EXISTS rest(id int NOT NULL AUTO_INCREMENT, url varchar(255), status int, antwortzeit int, aufgerufen datetime, PRIMARY KEY(id))");
				PreparedStatement createmail = dbcon.prepareStatement("CREATE TABLE IF NOT EXISTS alertemail(id int NOT NULL AUTO_INCREMENT,email varchar(255), PRIMARY KEY(id))");
				
				createdb.executeUpdate();
				usedb.executeUpdate();
				create.executeUpdate();
				createmail.executeUpdate();
							
				return dbcon;
						
			}catch(Exception e) {
				System.out.println(e);
			}	
			return null;
		}//getConnection()	
}//OracleCon
