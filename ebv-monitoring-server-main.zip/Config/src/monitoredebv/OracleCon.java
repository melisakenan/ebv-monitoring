package monitoredebv;

import java.sql.Connection;
import java.sql.*;

public class OracleCon {
	
	//Class.forName("oracle.jdbc.driver.OracleDriver");
	//Connection con = DriverManager.getConnection("jdbc:oracle:thin:@odbpsebvl.eb.lan.at:1521:ebvdbt.ebvldb", "ITMONITOR", "B73jGhe$wutj1mfi");

	public static void main(String[]args) throws Exception {
		//getConnection();
		//createTable();
		//post();		
	}
	
/*
	
	
	public static void createTable() throws Exception{
		
		try {
			Connection dbcon = getConnection();
			
			PreparedStatement createdb=dbcon.prepareStatement("CREATE DATABASE IF NOT EXISTS testdb");
			PreparedStatement usedb=dbcon.prepareStatement("USE testdb");
			PreparedStatement create = dbcon.prepareStatement("CREATE TABLE IF NOT EXISTS schnittstelle(id int NOT NULL AUTO_INCREMENT, url varchar(255), status int, antwortzeit int, aufgerufen datetime, PRIMARY KEY(id))");
			PreparedStatement createmail = dbcon.prepareStatement("CREATE TABLE IF NOT EXISTS alertemail(id int NOT NULL AUTO_INCREMENT,vorname varchar(255), nachname varchar(255), email varchar(255), PRIMARY KEY(id))");
			
			createdb.executeUpdate();
			usedb.executeUpdate();
			create.executeUpdate();
			createmail.executeUpdate();
			
		}catch(Exception e) {
			System.out.println(e);
		}
		finally {System.out.println("Function completed.");}
	}

	
	 public static Connection getConnection() throws Exception {
		try {
			
			/*String driver ="oracle.jdbc.driver.OracleDriver";
			String url = "jdbc:oracle:thin:@odbpsebvl.eb.lan.at:1521:ebvdbt.ebvldb";
			String username ="ITMONITOR";
			String password ="B73jGhe$wutj1mfi";
			
			Class.forName(driver);
			Connection dbcon = DriverManager.getConnection(url,username,password);
			System.out.println("Connected");
			return dbcon;
						
			String driver ="com.mysql.cj.jdbc.Driver";
			String url ="jdbc:mysql://127.0.0.1:3306/?user=root";
			String username ="root";
			String password="";
			
			Class.forName(driver);
			Connection dbcon = DriverManager.getConnection(url,username,password);
			System.out.println("Connected.");
			return dbcon;
					
		}catch(Exception e) {
			System.out.println(e);
		}	
		return null;
	}//getConnection()
	
	*/
	
}
